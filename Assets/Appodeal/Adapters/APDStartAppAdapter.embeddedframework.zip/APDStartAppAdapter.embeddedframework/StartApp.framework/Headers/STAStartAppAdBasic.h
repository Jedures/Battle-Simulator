//
//  STAStartAppAdBasic.h
//  StartApp
//
//  Created by Adir Genish on 3/3/15.
//  Copyright (c) 2015 StartApp. All rights reserved.
//  SDK version 3.3.5

#import <Foundation/Foundation.h>

@interface STAStartAppAdBasic : NSObject

+(BOOL)showAd;
@end
